
#include <SFML/Graphics.hpp>
#include <iostream>
#include <vector> // Include vector header for grid

const int gridSize = 8;
const int cellSize = 75; // Adjusted cell size to fit the pieces

class Piece {
protected:
    sf::Sprite sprite;

public:
    void setTexture(sf::Texture& texture, float scale) {
        sprite.setTexture(texture);
        sprite.setScale(sf::Vector2f(scale, scale)); // Adjust scale to fit within cell
    }

    void setPosition(float x, float y) {
        sprite.setPosition(x, y);
    }

    void draw(sf::RenderWindow& window) {
        window.draw(sprite);
    }

};

class Pawn : public Piece {
public:
    Pawn() {} // Default constructor

    Pawn(bool isWhite, sf::Texture& texture, float scale, float x, float y) {
        setColor(isWhite, texture, scale, x, y);
    }

    void setColor(bool isWhite, sf::Texture& texture, float scale, float x, float y) {
        setTexture(texture, scale);
        setPosition(x, y);
    }
};

class Rook : public Piece {
public:
    Rook(bool isWhite, sf::Texture& texture, float scale, float x, float y) {
        setColor(isWhite, texture, scale, x, y);
    }

    void setColor(bool isWhite, sf::Texture& texture, float scale, float x, float y) {
        setTexture(texture, scale);
        setPosition(x, y);
    }
};

class Knight : public Piece {
public:
    Knight(bool isWhite, sf::Texture& texture, float scale, float x, float y) {
        setColor(isWhite, texture, scale, x, y);
    }

    void setColor(bool isWhite, sf::Texture& texture, float scale, float x, float y) {
        setTexture(texture, scale);
        setPosition(x, y);
    }
};

class Bishop : public Piece {
public:
    Bishop(bool isWhite, sf::Texture& texture, float scale, float x, float y) {
        setColor(isWhite, texture, scale, x, y);
    }

    void setColor(bool isWhite, sf::Texture& texture, float scale, float x, float y) {
        setTexture(texture, scale);
        setPosition(x, y);
    }
};

class Queen : public Piece {
public:
    Queen(bool isWhite, sf::Texture& texture, float scale, float x, float y) {
        setColor(isWhite, texture, scale, x, y);
    }

    void setColor(bool isWhite, sf::Texture& texture, float scale, float x, float y) {
        setTexture(texture, scale);
        setPosition(x, y);
    }
};

class King : public Piece {
public:
    King(bool isWhite, sf::Texture& texture, float scale, float x, float y) {
        setColor(isWhite, texture, scale, x, y);
    }

    void setColor(bool isWhite, sf::Texture& texture, float scale, float x, float y) {
        setTexture(texture, scale);
        setPosition(x, y);
    }
};



int main() {
    // Create a window
    sf::RenderWindow window(sf::VideoMode(gridSize * cellSize, gridSize * cellSize), "CHESS");

    // Load font
    sf::Font font;
    if (!font.loadFromFile("fonts/ASMAN.ttf")) {
        std::cerr << "Failed to load font!" << std::endl;
        return 1;
    }

    // Text for names on cover page
    sf::Text namesTextCover;
    namesTextCover.setFont(font);
    namesTextCover.setString("Ayesha\nRida"); // Replace with your names
    namesTextCover.setCharacterSize(20);
    namesTextCover.setFillColor(sf::Color::White);
    namesTextCover.setStyle(sf::Text::Bold);
    namesTextCover.setPosition(20.f, 20.f);

    // Cover page text
    sf::Text pressEnterText;
    pressEnterText.setFont(font);
    pressEnterText.setString("Press ENTER to start");
    pressEnterText.setCharacterSize(30);
    pressEnterText.setFillColor(sf::Color::White);
    pressEnterText.setPosition(200.f, 500.f);

    // Boolean to track if cover page is displayed
    bool showCoverPage = true;

    // Variables for dragging
    bool isDragging = false;
    Piece* draggedPiece = nullptr;
    sf::Vector2f offset;

    // Main loop
    while (window.isOpen()) {
        // Event handling
        sf::Event event;
        while (window.pollEvent(event)) {
            if (event.type == sf::Event::Closed) {
                window.close();
            }
            // Check for ENTER key press to transition to game console
            if (event.type == sf::Event::KeyPressed && event.key.code == sf::Keyboard::Enter) {
                showCoverPage = false; // Hide cover page
            }
        }


        // Clear the window
        window.clear();

        if (showCoverPage) {
            // Draw the cover page
            window.draw(namesTextCover);
            window.draw(pressEnterText);
        }
        else {
            // Load textures for pieces
            sf::Texture rookTexture, knightTexture, knightTexture2, bishopTexture, bishopTexture2, kingTexture, kingTexture2, queenTexture, queenTexture2, pawnTexture, pawnTexture2, rookBlackTexture;
            if (!rookTexture.loadFromFile("rook.png") || !knightTexture.loadFromFile("knight.png") || !knightTexture2.loadFromFile("knight2.png") ||
                !bishopTexture.loadFromFile("bishop.png") || !bishopTexture2.loadFromFile("bishop2.png") || !kingTexture.loadFromFile("king.png") || !kingTexture2.loadFromFile("king2.png") ||
                !queenTexture.loadFromFile("queen.png") || !queenTexture2.loadFromFile("queen2.png") || !pawnTexture.loadFromFile("pawn.png") ||
                !pawnTexture2.loadFromFile("pawn2.png") || !rookBlackTexture.loadFromFile("rook2.png")) {
                std::cerr << "Failed to load one or more piece images!" << std::endl;
                return 1;
            }

            // Create piece instances
            Pawn whitePawns[8], blackPawns[8];
            Rook whiteRook(true, rookTexture, 0.2f, 0 * cellSize + 5, 0 * cellSize + 5);
            Rook whiteRook3(true, rookTexture, 0.2f, 7 * cellSize + 5, 0 * cellSize + 5);
            Rook blackRook(false, rookBlackTexture, 0.2f, 0 * cellSize + 5, 7 * cellSize + 5);
            Rook blackRook3(false, rookBlackTexture, 0.2f, 7 * cellSize + 5, 7 * cellSize + 5);
            Knight whiteKnight(true, knightTexture, 0.2f, 1 * cellSize + 5, 0 * cellSize + 5);
            Knight whiteKnight2(true, knightTexture, 0.2f, 6 * cellSize + 5, 0 * cellSize + 5);
            Knight blackKnight(false, knightTexture2, 0.2f, 1 * cellSize + 5, 7 * cellSize + 5);
            Knight blackKnight2(false, knightTexture2, 0.2f, 6 * cellSize + 5, 7 * cellSize + 5);
            Bishop whiteBishop(true, bishopTexture, 0.2f, 2 * cellSize + 5, 0 * cellSize + 5);
            Bishop whiteBishop2(true, bishopTexture, 0.2f, 5 * cellSize + 5, 0 * cellSize + 5);
            Bishop blackBishop(false, bishopTexture, 0.2f, 5 * cellSize + 5, 7 * cellSize + 5);
            Bishop blackBishop2(false, bishopTexture2, 0.2f, 2 * cellSize + 5, 7 * cellSize + 5);
            Bishop blackBishop3(false, bishopTexture2, 0.2f, 5 * cellSize + 5, 7 * cellSize + 5);
            Queen whiteQueen(true, queenTexture, 0.2f, 3 * cellSize + 5, 0 * cellSize + 5);
            Queen blackQueen(false, queenTexture2, 0.2f, 3 * cellSize + 5, 7 * cellSize + 5);
            King whiteKing(true, kingTexture, 0.2f, 4 * cellSize + 5, 0 * cellSize + 5);
            King blackKing(false, kingTexture2, 0.2f, 4 * cellSize + 5, 7 * cellSize + 5);
            for (int i = 0; i < 8; ++i) {
                whitePawns[i] = Pawn(true, pawnTexture, 0.2f, i * cellSize + 5, 1 * cellSize + 5);
                blackPawns[i] = Pawn(false, pawnTexture2, 0.2f, i * cellSize + 5, 6 * cellSize + 5);
            }
            // Draw the checkerboard pattern
            for (int i = 0; i < gridSize; ++i) {
                for (int j = 0; j < gridSize; ++j) {
                    sf::RectangleShape square(sf::Vector2f(cellSize, cellSize));
                    square.setPosition(j * cellSize, i * cellSize);
                    if ((i + j) % 2 == 0)
                        square.setFillColor(sf::Color::White);
                    else
                        square.setFillColor(sf::Color::Black);
                    window.draw(square);
                }
            }

            // Draw pieces
            whiteRook.draw(window);
            whiteRook3.draw(window);
            blackRook.draw(window);
            blackRook3.draw(window);
            whiteKnight.draw(window);
            whiteKnight2.draw(window);
            blackKnight.draw(window);
            blackKnight2.draw(window);
            whiteBishop.draw(window);
            whiteBishop2.draw(window);
            blackBishop.draw(window);
            blackBishop2.draw(window);
            blackBishop3.draw(window);
            whiteQueen.draw(window);
            blackQueen.draw(window);
            whiteKing.draw(window);
            blackKing.draw(window);
            for (int i = 0; i < 8; ++i) {
                whitePawns[i].draw(window);
                blackPawns[i].draw(window);
            }
        }

        // Display the window
        window.display();
    }

    return 0;
}

