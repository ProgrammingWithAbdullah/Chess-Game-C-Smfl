#include <iostream>
#include <SFML/Graphics.hpp>
#include <array>

class Piece : public sf::Drawable {

public:

    Piece(char type = 'P', bool player = true, int pos = -1, bool moved = false)
        : m_type{ type }, m_player{ player },
        m_position{ -1 }, m_moved{ true }, enPassant{ -1 }
    { }

    void setPiece(char type, bool player, int pos, bool moved = false);

    void setType(char ch) { m_type = ch; setTexture(); }
    char getType() { return m_type; }

    void setPlayer(bool bl) { m_player = bl; setTexture(); }
    bool getPlayer() { return m_player; }

    void setPosition(int pos) { m_position = pos; move(); }
    int getPosition() { return m_position; }

    void setMoved(bool moved) { m_moved = moved; }
    bool getMoved() { return m_moved; }

    void setEnPassant(int x) { enPassant = x; }
    int getEnPassant() { return enPassant; }

    std::vector<int>& getPossibleMoves() { return possibleMoves; }
    std::vector<int>& getDangerMoves() { return dangerMoves; }

    std::string toString();

private:
    sf::Sprite m_sprite;
    std::vector<int> possibleMoves;
    std::vector<int> dangerMoves; // Moves that endanger opposite king

    char m_type; //'K'=King , 'Q' = Queen , 'R' = Rook , 'B' = Bishop , 'N' = Knight , 'P' = Pawn
    bool m_player; // true == White , false == Black
    int m_position; // 0-63 board, -1 dead
    int enPassant;
    bool m_moved;

    void setTexture();
    void move();

    virtual void draw(sf::RenderTarget& target, sf::RenderStates states) const
    {
        target.draw(m_sprite);
    }
};
class Board : public sf::Drawable {

public:

    Board(sf::Color col1 = sf::Color::White, sf::Color col2 = sf::Color::Black);

    // Member function that sets Board stuff, can choose square colors in parameters
    void load(sf::Color col1 = sf::Color::White, sf::Color col2 = sf::Color::Black);

private:

    std::array<sf::RectangleShape, 64> m_boardSquares;

    // Draw class on SFML Window
    virtual void draw(sf::RenderTarget& target, sf::RenderStates states) const;

};
class ChessGame : public sf::Drawable {
private:
    Board board;
    std::array<Piece, 16> whitePieces;
    std::array<Piece, 16> blackPieces;
    Piece* selectedPiece;
    std::vector<sf::RectangleShape> possibleMovesSquares;
    std::string lastMove;

    sf::RectangleShape infoRestart;

    sf::Font font;
    sf::Text textRestart;
    sf::Text textTurn;
    sf::Text textSituation;
    sf::Text textLastMove;


    bool selected;
    bool playerTurn; // true = White turn, false = Black Turn
    bool playerTurnCheck;
    bool mate;
    int turn;

    void createMovesSquares();

    void calcPossibleMoves();
    void calcKingMoves(Piece* tmpPiece);
    void calcQueenMoves(Piece* tmpPiece);
    void calcRookMoves(Piece* tmpPiece);
    void calcBishopMoves(Piece* tmpPiece);
    void calcKnightMoves(Piece* tmpPiece);
    void calcPawnMoves(Piece* tmpPiece);
    void calcCastling(Piece* tmpPiece);

    void eraseMoves(Piece* tmpPiece);

    void checkMate();

    void updateInfo();

    virtual void draw(sf::RenderTarget& target, sf::RenderStates states) const;

public:
    ChessGame(sf::Color bordCol1, sf::Color bordCol2);

    bool getSelected() { return selected; }

    bool getMate() { return mate; }

    bool selectPiece(int pos);

    void moveSelected(int pos);

    void restart();



};

Board::Board(sf::Color col1, sf::Color col2) {
    load(col1, col2);
}

// Member function that sets Board stuff, can choose square colors in parameters
void Board::load(sf::Color col1, sf::Color col2) {
    for (int i = 0; i < 8; i++) {

        bool tmpColor = ((i % 2) == 0) ? true : false;

        for (int j = 0; j < 8; j++) {

            m_boardSquares[j + (i * 8)].setPosition(sf::Vector2f(j * 64.f, i * 64.f));
            m_boardSquares[j + (i * 8)].setSize(sf::Vector2f(64.f, 64.f));
            m_boardSquares[j + (i * 8)].setFillColor(tmpColor ? col1 : col2);

            tmpColor = !tmpColor;
        }
    }
}

// Draw class on SFML Window
void Board::draw(sf::RenderTarget& target, sf::RenderStates states) const {
    for (int i = 0; i < 64; i++) {
        target.draw(m_boardSquares[i]);
    }
}

int main() {
    ChessGame chess(sf::Color(0xf3bc7aff), sf::Color(0xae722bff));

    sf::RenderWindow window(sf::VideoMode(768, 512), "Chess", sf::Style::Titlebar | sf::Style::Close);
    window.setVerticalSyncEnabled(true);

    while (window.isOpen()) {

        sf::Event event;

        while (window.pollEvent(event)) {

            if (event.type == sf::Event::Closed)
                window.close();

            if (event.type == sf::Event::MouseButtonPressed) {
                if (event.mouseButton.button == sf::Mouse::Left) {
                    if ((0 <= event.mouseButton.x) && (event.mouseButton.x <= 512) && (0 <= event.mouseButton.y) && (event.mouseButton.y <= 512)) {
                        unsigned int buttonPos{ (event.mouseButton.x / 64) + ((event.mouseButton.y / 64) * (8 * (512 / window.getSize().y))) };

                        if (!chess.getSelected())
                            chess.selectPiece(buttonPos);
                        else
                            chess.moveSelected(buttonPos);
                    }
                    else if ((517 <= event.mouseButton.x) && (event.mouseButton.x <= 763) && (5 <= event.mouseButton.y) && (event.mouseButton.y <= 45)) {
                        chess.restart();
                    }
                }
            }
        }

        window.draw(chess);
        window.display();
    }
}