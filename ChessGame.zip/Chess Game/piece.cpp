#include <iostream>
#include <SFML/Graphics.hpp>

class PieceTextures {
public:
    static sf::Texture blackKing;
    static sf::Texture blackQueen;
    static sf::Texture blackRook;
    static sf::Texture blackKnight;
    static sf::Texture blackBishop;
    static sf::Texture blackPawn;

    static sf::Texture whiteKing;
    static sf::Texture whiteQueen;
    static sf::Texture whiteRook;
    static sf::Texture whiteKnight;
    static sf::Texture whiteBishop;
    static sf::Texture whitePawn;

    static sf::Texture loadTexture(std::string str);
};
class Piece : public sf::Drawable {

public:

    Piece(char type = 'P', bool player = true, int pos = -1, bool moved = false)
        : m_type{ type }, m_player{ player },
        m_position{ -1 }, m_moved{ true }, enPassant{ -1 }
    { }

    void setPiece(char type, bool player, int pos, bool moved = false);

    void setType(char ch) { m_type = ch; setTexture(); }
    char getType() { return m_type; }

    void setPlayer(bool bl) { m_player = bl; setTexture(); }
    bool getPlayer() { return m_player; }

    void setPosition(int pos) { m_position = pos; move(); }
    int getPosition() { return m_position; }

    void setMoved(bool moved) { m_moved = moved; }
    bool getMoved() { return m_moved; }

    void setEnPassant(int x) { enPassant = x; }
    int getEnPassant() { return enPassant; }

    std::vector<int>& getPossibleMoves() { return possibleMoves; }
    std::vector<int>& getDangerMoves() { return dangerMoves; }

    std::string toString();

private:
    sf::Sprite m_sprite;
    std::vector<int> possibleMoves;
    std::vector<int> dangerMoves; // Moves that endanger opposite king

    char m_type; //'K'=King , 'Q' = Queen , 'R' = Rook , 'B' = Bishop , 'N' = Knight , 'P' = Pawn
    bool m_player; // true == White , false == Black
    int m_position; // 0-63 board, -1 dead
    int enPassant;
    bool m_moved;

    void setTexture();
    void move();

    virtual void draw(sf::RenderTarget& target, sf::RenderStates states) const
    {
        target.draw(m_sprite);
    }
};

sf::Texture PieceTextures::loadTexture(std::string str) {
    sf::Texture tmp;
    if (!tmp.loadFromFile(str))
        std::cout << "Error loading file\n";
    return tmp;
}

sf::Texture PieceTextures::blackKing = PieceTextures::loadTexture("Textures/b_king.png");
sf::Texture PieceTextures::blackQueen = PieceTextures::loadTexture("Textures/b_queen.png");
sf::Texture PieceTextures::blackRook = PieceTextures::loadTexture("Textures/b_rook.png");
sf::Texture PieceTextures::blackKnight = PieceTextures::loadTexture("Textures/b_knight.png");
sf::Texture PieceTextures::blackBishop = PieceTextures::loadTexture("Textures/b_bishop.png");
sf::Texture PieceTextures::blackPawn = PieceTextures::loadTexture("Textures/b_pawn.png");

sf::Texture PieceTextures::whiteKing = PieceTextures::loadTexture("Textures/w_king.png");
sf::Texture PieceTextures::whiteQueen = PieceTextures::loadTexture("Textures/w_queen.png");
sf::Texture PieceTextures::whiteRook = PieceTextures::loadTexture("Textures/w_rook.png");
sf::Texture PieceTextures::whiteKnight = PieceTextures::loadTexture("Textures/w_knight.png");
sf::Texture PieceTextures::whiteBishop = PieceTextures::loadTexture("Textures/w_bishop.png");
sf::Texture PieceTextures::whitePawn = PieceTextures::loadTexture("Textures/w_pawn.png");

void Piece::setPiece(char type, bool player, int pos, bool moved) {
    setType(type);
    setPlayer(player);
    setPosition(pos); //m_moved true
    setMoved(moved); // m_moved false
}

std::string Piece::toString() {
    std::string str;

    str += m_player ? "White " : "Black ";

    switch (m_type)
    {
    case 'K':
        str += "King ";
        break;
    case 'Q':
        str += "Queen ";
        break;
    case 'R':
        str += "Rook ";
        break;
    case 'B':
        str += "Bishop ";
        break;
    case 'N':
        str += "Knight ";
        break;
    case 'P':
        str += "Pawn ";
        break;
    default:
        str += "??? ";
        break;
    }

    str += "\nto position\nX: ";
    str += std::to_string((m_position % 8) + 1);
    str += "  Y: ";
    str += std::to_string((m_position / 8) + 1);
    str += '\n';


    return str;

}

void Piece::move() {
    if (m_position <= -1 || 64 <= m_position) {
        m_position = -1;
        m_sprite.setColor(sf::Color(0x00000000));
        m_sprite.setPosition(sf::Vector2f((m_position % 8) * 64.f + 32.f, (m_position / 8) * 64.f + 32.f));
        possibleMoves.clear();
        m_moved = true;
    }
    else {
        m_sprite.setPosition(sf::Vector2f((m_position % 8) * 64.f + 32.f, (m_position / 8) * 64.f + 32.f));
        m_moved = true;
    }
    return;
}

void Piece::setTexture() {
    m_sprite = sf::Sprite();
    switch (m_type)
    {
    case 'K':
        m_sprite.setTexture(m_player ? PieceTextures::whiteKing : PieceTextures::blackKing);
        break;
    case 'Q':
        m_sprite.setTexture(m_player ? PieceTextures::whiteQueen : PieceTextures::blackQueen);
        break;
    case 'R':
        m_sprite.setTexture(m_player ? PieceTextures::whiteRook : PieceTextures::blackRook);
        break;
    case 'B':
        m_sprite.setTexture(m_player ? PieceTextures::whiteBishop : PieceTextures::blackBishop);
        break;
    case 'N':
        m_sprite.setTexture(m_player ? PieceTextures::whiteKnight : PieceTextures::blackKnight);
        break;
    case 'P':
        m_sprite.setTexture(m_player ? PieceTextures::whitePawn : PieceTextures::blackPawn);
        break;
    default:
        std::cerr << "Error piece type does not exist.\n";
        break;
    }
    m_sprite.setOrigin(sf::Vector2f(m_sprite.getTexture()->getSize().x / 2, m_sprite.getTexture()->getSize().y / 2));
    m_sprite.setScale(sf::Vector2f(0.375f, 0.375f));
}